# # 第一步：必须在最顶行设置环境变量，严禁任何其他 import 在其上方
# import os
#
# os.environ["KMP_DUPLICATE_LIB_OK"] = "TRUE"
#
# # 第二步：常规导入
# import argparse
# import torch as th
# from stable_baselines3 import PPO
# from stable_baselines3.common.callbacks import CheckpointCallback
# from stable_baselines3.common.vec_env import VecNormalize, VecMonitor
# from godot_rl.wrappers.stable_baselines_wrapper import StableBaselinesGodotEnv
#
#
# # ==========================================
# # 🧠 硬件与架构检测
# # ==========================================
# def check_environment():
#     print("\n" + "=" * 30)
#     print(f"PyTorch 版本: {th.__version__}")
#
#     # 核心检测：是否识别到您的 RTX 4060
#     cuda_available = th.cuda.is_available()
#     print(f"GPU (CUDA) 是否可用: {cuda_available}")
#
#     if cuda_available:
#         print(f"当前 GPU 设备: {th.cuda.get_device_name(0)}")
#         device = "cuda"
#     else:
#         print("⚠️ 警告: 未检测到 GPU，将回退至 CPU 训练。")
#         device = "cpu"
#     print("=" * 30 + "\n")
#     return device
#
#
# # ==========================================
# # ⚙️ 算法配置 (基于策划书适配)
# # ==========================================
# POLICY_KWARGS = dict(
#     activation_fn=th.nn.Tanh,
#     net_arch=dict(pi=[256, 256], vf=[256, 256])
# )
#
# HYPERPARAMS = {
#     "learning_rate": 3e-4,
#     "n_steps": 4096,
#     "batch_size": 512,
#     "n_epochs": 10,
#     "gamma": 0.995,
#     "gae_lambda": 0.95,
#     "clip_range": 0.2,
#     "ent_coef": 0.01,
# }
#
#
# def train(args):
#     # 执行硬件检测
#     device = check_environment()
#
#     print(f"🚀 连接 Godot 编辑器 (端口 11008)...")
#
#     # 1. 创建 Godot 向量化环境
#     env = StableBaselinesGodotEnv(
#         env_path=args.env_path,
#         show_window=not args.headless,
#         speedup=args.speedup,
#         n_parallel=1
#     )
#
#     # 2. 向量化监控包装器 (解决日志记录问题)
#     env = VecMonitor(env)
#
#     # 3. 奖励归一化 (符合策划书数值稳定性要求)
#     env = VecNormalize(env, norm_obs=False, norm_reward=True, clip_reward=10.0)
#
#     # 4. 初始化 PPO 模型
#     model = PPO(
#         "MultiInputPolicy",
#         env,
#         policy_kwargs=POLICY_KWARGS,
#         verbose=1,
#         device=device,  # 显式指定使用 CUDA 或 CPU
#         tensorboard_log="./logs/survivor_evo/",
#         **HYPERPARAMS
#     )
#
#     # 5. 自动保存回调
#     checkpoint_callback = CheckpointCallback(
#         save_freq=50000,
#         save_path="./checkpoints/",
#         name_prefix="survivor_evo"
#     )
#
#     print(f"🎯 训练启动！目标: {args.timesteps} 步")
#
#     try:
#         model.learn(
#             total_timesteps=args.timesteps,
#             callback=checkpoint_callback,
#             progress_bar=True  # 需执行 pip install tqdm rich
#         )
#     except KeyboardInterrupt:
#         print("\n🛑 收到中断信号，正在安全保存...")
#
#     # 6. 持久化存储
#     os.makedirs("models", exist_ok=True)
#     model.save("models/survivor_final")
#     env.save("models/survivor_final_vecnorm.pkl")
#     print("✅ 保存完成。")
#
#     env.close()
#
#
# if __name__ == "__main__":
#     parser = argparse.ArgumentParser()
#     parser.add_argument("--env_path", default=None, type=str)
#     parser.add_argument("--timesteps", default=2000000, type=int)
#     parser.add_argument("--speedup", default=8, type=int)
#     parser.add_argument("--headless", action="store_true")
#
#     args = parser.parse_args()
#     train(args)


# ==========================================================
# 🚀 Godot RL Agents 训练脚本 (支持断点续传)
# ==========================================================
# 用法说明:
# 1. 全新训练: 确保 models/ 文件夹为空，直接运行 python train.py
# 2. 断点续传: 确保 models/ 下有 survivor_final.zip 和 survivor_final_vecnorm.pkl
#    脚本会自动读取它们并从上次的 total_timesteps 继续。
# 3. 监控: 运行 tensorboard --logdir=logs/ 并在浏览器打开 http://localhost:6006
# ==========================================================

import os
import argparse
import torch as th

# [核心修复] 必须在导入任何 AI 库之前设置环境变量，解决 OpenMP 冲突
os.environ["KMP_DUPLICATE_LIB_OK"] = "TRUE"

from stable_baselines3 import PPO
from stable_baselines3.common.callbacks import CheckpointCallback
from stable_baselines3.common.vec_env import VecNormalize, VecMonitor
from godot_rl.wrappers.stable_baselines_wrapper import StableBaselinesGodotEnv


def train(args):
    # 路径配置
    MODEL_DIR = "models"
    LOG_DIR = "logs/survivor_evo/PPO_7"
    MODEL_PATH = os.path.join(MODEL_DIR, "survivor_final.zip")
    STATS_PATH = os.path.join(MODEL_DIR, "survivor_final_vecnorm.pkl")

    # 确保目录存在
    os.makedirs(MODEL_DIR, exist_ok=True)
    os.makedirs("checkpoints/", exist_ok=True)

    print("\n" + "=" * 30)
    print(f"PyTorch 版本: {th.__version__}")
    print(f"GPU (CUDA) 可用: {th.cuda.is_available()}")
    if th.cuda.is_available():
        print(f"当前 GPU 设备: {th.cuda.get_device_name(0)}")
    print("=" * 30 + "\n")

    # 1. 初始化 Godot 环境
    print(f"🚀 正在连接 Godot (Speedup: {args.speedup}x)...")
    # n_parallel=1 对应单实例训练，若需多开可增加此值
    env = StableBaselinesGodotEnv(speedup=args.speedup, n_parallel=1)

    # 2. 包装监控器 (记录数据到 Tensorboard)
    env = VecMonitor(env)

    # 3. 处理奖励归一化 (VecNormalize)
    # [关键] 恢复上一次训练的奖励统计数据，防止模型崩溃
    if os.path.exists(STATS_PATH):
        print(f"📈 正在恢复奖励归一化统计数据: {STATS_PATH}")
        env = VecNormalize.load(STATS_PATH, env)
    else:
        print("ℹ️ 未发现统计数据，初始化新的归一化层。")
        env = VecNormalize(env, norm_obs=False, norm_reward=True, clip_reward=10.0)

    # 4. 加载模型或新建模型
    if os.path.exists(MODEL_PATH):
        print(f"♻️ 发现现有模型，正在执行断点续传: {MODEL_PATH}")
        # 加载模型并绑定到当前环境
        model = PPO.load(
            MODEL_PATH,
            env=env,
            device="cuda" if th.cuda.is_available() else "cpu",
            # 继续训练时可以根据需要调整学习率 (可选)
            custom_objects={"learning_rate": 1e-4}
        )
    else:
        print("🆕 未发现现有模型，开启全新训练流程。")
        model = PPO(
            "MultiInputPolicy",
            env,
            policy_kwargs=dict(
                activation_fn=th.nn.Tanh,
                net_arch=dict(pi=[256, 256], vf=[256, 256])
            ),
            verbose=1,
            device="cuda" if th.cuda.is_available() else "cpu",
            tensorboard_log=LOG_DIR,
            n_steps=4096,
            batch_size=512,
            n_epochs=10,
            learning_rate=3e-4,
            gamma=0.995,
            ent_coef=0.01
        )

    # 5. 配置自动保存
    checkpoint_callback = CheckpointCallback(
        save_freq=50000,
        save_path="checkpoints/",
        name_prefix="survivor_auto"
    )

    # 6. 执行训练
    print(f"🎯 训练开始！目标总步数: {args.timesteps}")
    try:
        # [关键] reset_num_timesteps=False 确保 TensorBoard 曲线连续
        model.learn(
            total_timesteps=args.timesteps,
            callback=checkpoint_callback,
            progress_bar=True,
            reset_num_timesteps=False
        )
    except KeyboardInterrupt:
        print("\n🛑 收到手动中断信号，正在执行紧急保存...")

    # 7. 保存最终结果
    model.save(MODEL_PATH)
    env.save(STATS_PATH)
    print(f"✅ 训练结束。模型已保存至: {MODEL_PATH}")

    env.close()


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--timesteps", default=2000000, type=int, help="训练总步数")
    parser.add_argument("--speedup", default=8, type=int, help="Godot 物理加速倍数")

    args = parser.parse_args()
    train(args)