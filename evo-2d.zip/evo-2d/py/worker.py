import os

# 1. 必须在所有导入前设置，解决 OpenMP 冲突
os.environ["KMP_DUPLICATE_LIB_OK"] = "TRUE"

import argparse
import time
import socket
import json
import torch as th
from stable_baselines3 import PPO
from stable_baselines3.common.callbacks import CheckpointCallback, BaseCallback
from stable_baselines3.common.vec_env import VecNormalize, VecMonitor
from godot_rl.wrappers.stable_baselines_wrapper import StableBaselinesGodotEnv
import godot_rl.core.godot_env
import struct

# ==========================================
# 🔧 [深度修复] 强制 Client 模式并主动发送协议头
# ==========================================
def force_godot_env_client_mode():
    """
    Monkey Patch:
    1. 主动连接 Godot。
    2. 发送带有 4 字节长度头的 JSON 数据 (Godot StreamPeer 协议要求)。
    """

    # 辅助函数：打包发送带长度头的消息
    def _send_packed_json(connection, msg_dict):
        json_str = json.dumps(msg_dict)
        json_bytes = json_str.encode("utf-8")
        # struct.pack('<I', ...) 表示：小端序 (Little Endian) 的无符号整数 (Unsigned Int)
        # 这是 Godot get_string() 默认解析的长度格式
        header = struct.pack('<I', len(json_bytes))
        connection.sendall(header + json_bytes)

    def _client_connect_and_handshake(self):
        self.port = self.port if self.port else 11008
        print(f"🔄 [Client Mode] 正在尝试连接 Godot 服务器 (127.0.0.1:{self.port})...")

        self.connection = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.connection.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)

        connected = False
        while not connected:
            try:
                self.connection.connect(("127.0.0.1", self.port))
                connected = True
                print(f"✅ [Client Mode] 成功连接到 Godot 服务器！")
            except ConnectionRefusedError:
                print(f"⏳ 连接被拒绝，Godot 是否已启动并在监听端口 {self.port}? 1秒后重试...")
                time.sleep(1.0)
            except Exception as e:
                print(f"❌ 连接错误: {e}")
                time.sleep(1.0)

        self.connection.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)

        # === [关键修复] 发送带长度头的协议包 ===
        print("📤 [Protocol] 发送 Handshake (带长度头)...")
        _send_packed_json(self.connection, {
            "type": "handshake",
            "major_version": "0",
            "minor_version": "7"
        })

        print("📤 [Protocol] 发送 Env Info 请求 (带长度头)...")
        _send_packed_json(self.connection, {"type": "env_info"})

        return self.connection

    def _skip_handshake(self):
        print("⏭️ [Protocol] 跳过原库的握手等待逻辑")
        pass

    godot_rl.core.godot_env.GodotEnv._start_server = _client_connect_and_handshake
    godot_rl.core.godot_env.GodotEnv._handshake = _skip_handshake
    print("🔧 已应用全套补丁：TCP Client + 长度前缀协议")



# ==========================================
# 💾 自定义回调
# ==========================================
class SaveVecNormalizeCallback(BaseCallback):
    def __init__(self, save_freq: int, save_path: str, name_prefix: str, verbose=1):
        super().__init__(verbose)
        self.save_freq = save_freq
        self.save_path = save_path
        self.name_prefix = name_prefix

    def _init_callback(self) -> None:
        if self.save_path is not None:
            os.makedirs(self.save_path, exist_ok=True)

    def _on_step(self) -> bool:
        if self.n_calls % self.save_freq == 0:
            path = os.path.join(self.save_path, f"{self.name_prefix}_{self.num_timesteps}_steps.pkl")
            if self.training_env is not None:
                env = self.training_env
                if isinstance(env, VecNormalize):
                    env.save(path)
                elif hasattr(env, "venv") and isinstance(env.venv, VecNormalize):
                    env.venv.save(path)
                else:
                    try:
                        self.training_env.save(path)
                    except AttributeError:
                        pass
        return True


# ==========================================
# ⚙️ Worker 配置
# ==========================================
POLICY_KWARGS = dict(
    activation_fn=th.nn.Tanh,
    net_arch=dict(pi=[512, 512, 256], vf=[512, 512, 256])
)

HYPERPARAMS = {
    "learning_rate": 3e-4,
    "n_steps": 4096,
    "batch_size": 512,
    "n_epochs": 10,
    "gamma": 0.995,
    "gae_lambda": 0.95,
    "ent_coef": 0.01,
}


def train_worker(args):
    TIMESTAMP = time.strftime("%Y%m%d-%H%M%S")
    BASE_DIR = f"./models/worker_{TIMESTAMP}"
    CHECKPOINT_DIR = os.path.join(BASE_DIR, "checkpoints")
    LOG_DIR = f"./logs/worker_{TIMESTAMP}/"

    os.makedirs(CHECKPOINT_DIR, exist_ok=True)
    os.makedirs(LOG_DIR, exist_ok=True)

    print("\n" + "=" * 50)
    print(f"🚀 [Phase 1] 启动 Worker 训练 (CLIENT 模式)")
    print(f"📂 存档路径: {BASE_DIR}")
    print("=" * 50)

    # [应用修复补丁]
    force_godot_env_client_mode()

    try:
        env = StableBaselinesGodotEnv(
            env_path=args.env_path,
            show_window=False,    # 可视化开关 not args.headless 开 False 关
            speedup=args.speedup,
            n_parallel=1,
            port=11008
        )

        print("\n🎉 [SUCCESS] 握手成功！数据通道已建立。")
        print("-" * 40)

        # 简单校验
        total_obs_dim = 0
        for key, space in env.observation_space.spaces.items():
            total_obs_dim += space.shape[0]
        print(f"📈 总观察维度: {total_obs_dim}")
        print(f"🎮 动作空间: {env.action_space}")
        print("-" * 40 + "\n")

    except Exception as e:
        import traceback
        print(f"\n❌ [ERROR] 环境初始化失败: {e}")
        print(traceback.format_exc())
        return

    env = VecMonitor(env)
    env = VecNormalize(env, norm_obs=True, norm_reward=True, clip_reward=10.0)

    model = PPO(
        "MultiInputPolicy",
        env,
        policy_kwargs=POLICY_KWARGS,
        verbose=1,
        tensorboard_log=LOG_DIR,
        device="cuda" if th.cuda.is_available() else "cpu",
        **HYPERPARAMS
    )

    checkpoint_callback = CheckpointCallback(
        save_freq=50000,
        save_path=CHECKPOINT_DIR,
        name_prefix="worker_ckpt"
    )
    stats_callback = SaveVecNormalizeCallback(
        save_freq=50000,
        save_path=CHECKPOINT_DIR,
        name_prefix="worker_stats"
    )

    print(f"🎯 目标步数: {args.timesteps}")

    try:
        model.learn(
            total_timesteps=args.timesteps,
            callback=[checkpoint_callback, stats_callback],
            progress_bar=True
        )
    except KeyboardInterrupt:
        print("\n🛑 中断保存...")
    finally:
        model.save(os.path.join(BASE_DIR, "worker_final"))
        env.save(os.path.join(BASE_DIR, "worker_vecnorm.pkl"))
        env.close()


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--timesteps", default=3000000, type=int)
    parser.add_argument("--speedup", default=8, type=int)
    parser.add_argument("--headless", action="store_true")
    parser.add_argument("--env_path", default=None)
    args = parser.parse_args()

    train_worker(args)


# tensorboard --logdir="D:\Godot\evo-2d\py\logs\worker_xxxx\PPO_1"