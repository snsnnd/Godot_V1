D:\Godot\evo-2d\Scripts\Characters\Components\SensorSystem.gd
D:\Godot\evo-2d\Scripts\Characters\BaseUnit.gd
D:\Godot\evo-2d\Scripts\Characters\Survivor.gd

D:\Godot\evo-2d\Scripts\Control\BaseController.gd
D:\Godot\evo-2d\Scripts\Control\PlayerController.gd
D:\Godot\evo-2d\Scripts\Control\RLAgentController.gd

D:\Godot\evo-2d\Scripts\Core\GameLevelManager.gd

D:\Godot\evo-2d\Scripts\Environment\Hurtbox.gd
D:\Godot\evo-2d\Scripts\Environment\ResourceNode.gd

D:\Godot\evo-2d\Scripts\Systems\control\ControlSystem.gd
D:\Godot\evo-2d\Scripts\Systems\entity\ObjectSpawner.gd
D:\Godot\evo-2d\Scripts\Systems\map\MapDebugDraw.gd
D:\Godot\evo-2d\Scripts\Systems\map\MapGenerator.gd
D:\Godot\evo-2d\Scripts\Systems\map\TerrainGenerator.gd
D:\Godot\evo-2d\Scripts\Systems\map\ZoneManager.gd

D:\Godot\evo-2d\Scripts\UI\MainHUD.gd




D:\Godot\evo-2d\Scenes\characters\BaseUnit.tscn
D:\Godot\evo-2d\Scenes\characters\Boss.tscn
D:\Godot\evo-2d\Scenes\characters\Survivor.tscn
D:\Godot\evo-2d\Scenes\characters\infected\Infected_Agility.tscn
D:\Godot\evo-2d\Scenes\characters\infected\Infected_Minion.tscn
D:\Godot\evo-2d\Scenes\characters\infected\Infected_Summoner.tscn
D:\Godot\evo-2d\Scenes\characters\infected\Infected_Tank.tscn

D:\Godot\evo-2d\Scenes\Core\game_root.tscn

D:\Godot\evo-2d\Scenes\environment\resources\Stone.tscn
D:\Godot\evo-2d\Scenes\environment\resources\Wood.tscn
D:\Godot\evo-2d\Scenes\environment\traps\Construct_Trap.tscn
D:\Godot\evo-2d\Scenes\environment\zones\Effect_SlowZone.tscn
D:\Godot\evo-2d\Scenes\environment\zones\Zone_Buff.tscn
D:\Godot\evo-2d\Scenes\environment\zones\Zone_Debuff.tscn

D:\Godot\evo-2d\Scenes\ui\MainHUD.tscn
D:\Godot\evo-2d\Scenes\ui\OverheadUI.tscn
D:\Godot\evo-2d\Scenes\ui\Visual_DamageNum.tscn
D:\Godot\evo-2d\Scenes\ui\Visual_SkillIndicator.tscn




D:\Godot\evo-2d\Assets\TileSets\GameTiles.tres



D:\Godot\evo-2d\_autoload\GameManager.gd

使用的插件：godot_rl_agent



# 一、当前项目架构

evo-2d/
├── _autoload/                          # 全局单例加载
│   └── GameManager.gd                  # 全局游戏状态、进度及逻辑调度
│
├── Assets/                             # 静态资源
│   └── TileSets/
│       └── GameTiles.tres              # 游戏地形切片集
│
├── Scenes/                             # 场景文件 (节点树结构)
│   ├── characters/                     # 角色相关场景
│   │   ├── infected/                   # 感染者(敌人)变体
│   │   │   ├── Infected_Agility.tscn   # 敏捷型敌人
│   │   │   ├── Infected_Minion.tscn    # 基础杂兵
│   │   │   ├── Infected_Summoner.tscn  # 召唤型敌人
│   │   │   └── Infected_Tank.tscn      # 坦克型敌人
│   │   ├── BaseUnit.tscn               # 所有单位的基础场景
│   │   ├── Boss.tscn                   # Boss级单位
│   │   └── Survivor.tscn               # 幸存者(玩家/友方)场景
│   │
│   ├── Core/                           # 核心逻辑场景
│   │   └── game_root.tscn              # 游戏主根节点
│   │
│   ├── environment/                    # 环境与物件
│   │   ├── resources/                  # 可采集资源
│   │   │   ├── Stone.tscn              # 石材资源点
│   │   │   └── Wood.tscn               # 木材资源点
│   │   ├── traps/                      # 陷阱
│   │   │   └── Construct_Trap.tscn     # 可建造的陷阱
│   │   └── zones/                      # 区域效果
│   │       ├── Effect_SlowZone.tscn    # 减速区域
│   │       ├── Zone_Buff.tscn          # 增益区域
│   │       └── Zone_Debuff.tscn        # 减益区域
│   │
│   └── ui/                             # 用户界面场景
│       ├── MainHUD.tscn                # 主界面 UI
│       ├── OverheadUI.tscn             # 单位头顶 UI
│       ├── Visual_DamageNum.tscn       # 伤害数字飘字
│       └── Visual_SkillIndicator.tscn  # 技能范围/方向指示器
│
└── Scripts/                            # 逻辑脚本 (GDScript)
    ├── Characters/                     # 角色行为逻辑
    │   ├── Components/                 # 角色功能组件
    │   │   └── SensorSystem.gd         # 感知系统（用于 RL 或 AI 检测环境）
    │   ├── BaseUnit.gd                 # 单位基础属性与通用逻辑
    │   └── Survivor.gd                 # 幸存者特有逻辑
    │
    ├── Control/                        # 控制层逻辑 (Strategy Pattern)
    │   ├── BaseController.gd           # 控制器基类
    │   ├── PlayerController.gd         # 玩家手动控制实现
    │   └── RLAgentController.gd        # 强化学习 Agent 控制实现 (godot_rl_agents)
    │
    ├── Core/                           # 核心调度
    │   └── GameLevelManager.gd         # 关卡流程管理
    │
    ├── Environment/                    # 环境交互
    │   ├── Hurtbox.gd                  # 伤害判定区域逻辑
    │   └── ResourceNode.gd              # 资源点交互逻辑
    │
    ├── Systems/                        # 后台系统模块
    │   ├── control/
    │   │   └── ControlSystem.gd        # 控制权分配系统
    │   ├── entity/
    │   │   └── ObjectSpawner.gd        # 实体(单位/物品)生成器
    │   ├── map/                        # 地图生成相关
    │   │   ├── MapDebugDraw.gd         # 地图调试绘制工具
    │   │   ├── MapGenerator.gd         # 主地图生成逻辑
    │   │   ├── TerrainGenerator.gd     # 地形特征生成
    │   │   └── ZoneManager.gd          # 区域(Zone)触发与管理
    │
    └── UI/                             # UI 交互逻辑
        └── MainHUD.gd                  # 主 HUD 数据更新



# 二、脚本具体实现

## 一、Core

### Core/GameLevelManager

#### 1. 核心功能实现

- **游戏状态管理**：通过 `State` 枚举定义了 `LOADING`（加载）、`PLAYING`（进行中）、`PAUSED`（暂停）和 `GAME_OVER`（结束）四种状态 
- **自动化流程调度**：
  - **启动/重置流程**：在 `_ready()` 或 `reset_game()` 时触发地图生成，并监听地图完成信号。
  - **动态导航烘焙**：在地图生成后，自动调用 `NavigationRegion2D` 进行导航网格烘焙，确保 AI 路径可用 。
- **多控制器管理**：
  - **控制器初始化**：自动创建 1 个玩家控制器（`PlayerController`）和 11 个 AI 控制器（`RLAgentController`）。
  - **智能分配**：支持 `training_mode`（训练模式）。在训练模式下，所有 12 个单位都分配给 AI；在演示模式下，1 个分配给玩家，剩余分配给 AI。
- **游戏结束与重置逻辑**：
  - **监控条件**：每物理帧检查游戏时长（超过 `max_game_time`）或全员阵亡（`alive_survivor_count == 0`）。
  - **软重置（Soft Reset）**：重置时清理旧引用、重置计时器并保存训练数据，随后请求重新生成地图以提高 RL 训练的泛化性。
- **数据统计与持久化**：
  - 在每轮游戏结束时，统计存活时间以及幸存者采集的木材、石材总量。
  - 将结果以 CSV 格式保存至本地 `user://training_logs.csv` 路径。



#### 2. 关键代码内容

该脚本通过引用其他子系统（如 `ObjectSpawner`、`ControlSystem`）来实现其功能：

| **模块**     | **实现内容**                                                 |
| ------------ | :----------------------------------------------------------- |
| **状态变量** | `current_state` (当前状态), `current_game_time` (当前耗时), `alive_survivor_count` (存活数) |
| **外部引用** | `@export var map_system` (地图系统), `spawner` (生成器), `control_system` (控制系统) |
| **关键方法** | `_on_map_ready()`: 核心同步点，负责生成实体、烘焙导航并分配控制器 |
| **关键方法** | `_assign_units()`: 处理单位“附身”逻辑，区分玩家与 AI 控制权  |
| **辅助逻辑** | `_find_tilemap_layer()`: 递归查找地图系统中的 `TileMapLayer` 节点 |





## 二、Systems

### Systems/control/ControlSystem

#### 1. 核心功能实现

**集中化 AI 指挥**：作为一个中心节点，遍历并管理其所有的子节点（控制器），统一为它们下达指令 。

**性能优化调度**：引入了 `update_interval`（更新间隔）机制，通过帧计数器限制目标搜索频率，避免每一帧都进行全量距离计算，从而节省性能 。

**动态目标分配**：系统会自动扫描地图中 `resources` 分组的所有资源点，并计算每个 AI 角色当前位置与这些资源点的距离 。

**路径规划协同**：将找到的最近资源点坐标赋值给角色实体的 `NavigationAgent2D` 目标位置。这直接为 `RLAgentController` 提供了导航参考（nav_hint），是 AI 决策层获取环境观测数据的关键环节 。

**控制器纳管**：提供 `register_controller` 接口，支持将外部创建的控制器动态挂载到系统下进行统一管理 。



#### 2. 关键代码内容

| **模块**       | **实现内容**                                                 |
| -------------- | ------------------------------------------------------------ |
| **配置变量**   | `@export var update_interval`: 定义更新频率（默认 10 帧/次）；`is_active`: 控制系统运行的总开关。 |
| **频率控制**   | `_physics_process`: 内部维护 `_frame_count`，仅在满足间隔且游戏激活时触发更新。 |
| **目标指派**   | `_assign_target_to_agent`: 核心逻辑，通过 `controller.pawn.nav_agent.target_position` 注入导航目标。 |
| **搜索算法**   | `_find_closest_node`: 使用 `distance_squared_to`（距离平方比对）进行性能最优的最近邻搜索，避免了开平方运算的消耗。 |
| **控制器管理** | `register_controller`: 确保控制器节点被正确转移并添加至 `ControlSystem` 节点树下。 |





### Systems/entity/ObjectSpawner

#### 1. 核心功能实现

**自动化实体部署**：在地图生成完成后，根据传入的可行走坐标列表（`walkable_coords`），自动放置幸存者、木材和矿石 。

**动态难度配置**：内置简单的难度等级系统（`difficulty_level`），能够根据设定的等级动态调整生成的角色数量和资源丰度（例如：等级 2 增加角色和资源，等级 3 减少资源以增加挑战） 。

**随机化分布机制**：通过对坐标池进行洗牌（`shuffle`）并使用弹出（`pop_back`）操作，确保每一局游戏的资源和单位分布都是随机且不重叠的 。

**环境一致性管理**：负责在每轮游戏开始前执行 `_clear_all_entities`，彻底清理上一局残留的角色和资源，为软重置（Soft Reset）提供干净的环境 。

**视觉与交互优化**：在生成资源时对精灵图进行随机水平翻转，增加环境的自然感；同时将资源挂载到地图节点下，以支持 Y-Sort 遮挡排序 。



#### 2. 关键代码内容

| **模块**         | **实现内容**                                                 |
| ---------------- | ------------------------------------------------------------ |
| **预制体配置**   | 使用 `@export` 暴露 `survivor_scene`、`wood_scene` 和 `stone_scene`，允许在编辑器中直接拖拽赋值。 |
| **坐标转换逻辑** | 利用 `map_to_local(coord)` 将 TileMap 的网格坐标转换为实际的世界像素坐标。 |
| **容器化管理**   | 自动查找或创建名为 "Characters" 的节点作为单位容器，保持场景树整洁。 |
| **生成循环**     | `spawn_entities` 函数通过多个 `for` 循环依次处理角色、木头和矿石的生成逻辑。 |
| **清理机制**     | `_clear_all_entities` 通过遍历容器子节点和 `resources` 分组来执行 `queue_free()`。 |





### Systems/map/MapDebugDraw

#### 1. 核心功能实现

**可视化区域调试 (Visual Debugging)**：

- **实时区域绘制**：通过 `_draw()` 函数将 `ZoneManager` 中的逻辑地图数据（TileMap 坐标）转换为屏幕上的彩色矩形，直观展示不同阵营的势力范围 。
- **状态反馈**：支持三种状态的颜色区分：中立（白色）、优势（金色）与劣势（红色）。

**智能边界描边 (Smart Border Stroke)**：

- **边缘检测算法**：通过检查每个瓦片四个方向（上、下、左、右）的邻居类型。只有当邻居与当前瓦片类型不一致或为空时，才会绘制边界线 。
- **视觉增强**：利用粗线径（`line_width`）和黑色线条，在不同颜色的填充区域之间勾勒出清晰的轮廓边界 。

**动态渲染控制**：

- **开关管理**：提供 `enable_debug` 变量，允许在运行时通过编辑器或代码快速开启/关闭调试图层，减少非调试状态下的性能开销 。
- **分层优化**：将 `z_index` 设为 100，确保调试图形始终覆盖在游戏图块、单位及阴影之上，不被遮挡 。



#### 2. 关键代码内容

| **模块**                                | **实现内容**                                                 |
| --------------------------------------- | ------------------------------------------------------------ |
| **状态变量**                            | `enable_debug` (显示开关), `line_width` (线宽), `Alpha` (填充透明度) |
| **外部引用**                            | `@onready var zone_manager`: 核心数据源，提供 `tile_zone_map` 字典 |
| **核心方法 `_draw()`**                  | 遍历 `map` 字典，计算每个瓦片的像素位置并调用填充与描边逻辑  |
| **核心方法 `_draw_border_if_needed()`** | **边界计算逻辑**：使用 `match direction` 确定 `draw_line` 的起始点和终点坐标 |
| **颜色配置**                            | `zone_colors` 字典：定义了 `0` (White), `1` (Gold), `2` (Red) 的映射关系 |





### Systems/map/MapGenerator

#### 1. 核心功能实现

**自动化流水线调度**：

- **流程管控**：协调地形生成（Terrain）、区域划分（Zone）和导航烘焙（Navigation）三个阶段的顺序执行 。
- **依赖注入与自检**：在 `_ready()` 阶段自动查找并绑定 `GroundLayer` 到生成器，并对关键节点（如 `NavigationRegion2D`）进行防御性检查 。

**动态导航网格构建**：

- **异步烘焙**：在地形生成后触发 `bake_navigation_polygon()`，实现 AI 寻路网格的实时更新 。
- **物理同步优化**：通过 `await get_tree().physics_frame` 确保在烘焙前物理碰撞体已更新，防止 AI 出现穿墙逻辑错误 。

**区域系统集成**：

- **空间划分**：调用 `ZoneManager` 根据可行走坐标（walkable_coords）划分不同的游戏区域（Zone） 。
- **调试反馈**：生成完成后自动请求 `MapDebugDraw` 重新绘制，以可视化方式反馈生成的地图结构 。

**系统间通信枢纽**：

- **对外解耦**：作为地图系统的统一入口，通过 `map_ready` 信号将最终生成的行走坐标和区域管理引用发送给上层管理者（GameLevelManager） 。



#### 2. 关键代码内容

| **模块**         | **实现内容**                                                 |
| ---------------- | ------------------------------------------------------------ |
| **外部通信**     | `signal map_ready`: 地图构建全流程完毕后的核心同步信号 。    |
| **子组件引用**   | `@onready` 引用 `terrain_gen` (地形), `zone_gen` (区域), `debug_draw` (调试), `nav_region` (导航) 。 |
| **初始化逻辑**   | `_ready()`: 负责 `GroundLayer` 的自动绑定与 `terrain_generated` 信号的监听 。 |
| **流程入口**     | `start_generation()`: 启动地图生成的防御性方法，检查图层引用是否合法 。 |
| **核心处理逻辑** | `_on_terrain_generated()`: 包含区域划分、**物理帧等待**、**导航烘焙**及**信号发送**的核心序列 。 |





### Systems/map/TerrainGenerator

#### 1. 核心功能实现

**基于噪声的岛屿地形生成**：

- **程序化生成**：利用 `FastNoiseLite` 结合 `random_seed` 实现可重现的地形随机化 。
- **岛屿形态控制**：通过计算每个坐标到地图中心的距离，并应用 `smoothstep` 距离遮罩（Mask），使生成的地形在边缘平滑过渡为水域，呈现岛屿状 。
- **多级地貌划分**：通过设定 `wall_level`、`ground_level` 等阈值，将原始噪声数据划分为水域（WATER）、沙地（SAND）、草地（GROUND）和高峰（WALL）四种逻辑类型 。

**拓扑连通性清洗**：

- **孤岛识别**：使用洪水填充（Flood Fill）算法遍历地图，识别出所有相互独立的陆地板块（Islands） 。
- **最大连通区保留**：自动筛选面积最大的岛屿并保留，将其他无法到达的小型孤岛强行转换为水域，确保玩家与 AI 的活动空间是连通的 。

**图块渲染与坐标导出**：

- **图集映射**：将逻辑类型映射到 TileSet 具体的图集坐标（Atlas Coords），实现自动铺设 。
- **可行走区域记录**：筛选出沙地与草地坐标，存储至 `walkable_coords` 数组并发送信号，供后续系统（如资源生成）使用 。



#### 2. 关键代码内容

| **模块**                           | **实现内容**                                                 |
| ---------------------------------- | ------------------------------------------------------------ |
| **配置参数**                       | `map_width`/`height` (地图尺寸), `random_seed` (种子), `noise_freq` (频率) |
| **逻辑类型**                       | `enum TileType`: 定义了 WATER, SAND, GROUND, WALL 四种瓦片属性 |
| **外部引用**                       | `@export var ground_layer`: 目标绘制层；`TILE_SOURCE_ID`: 绑定的 TileSet 图集 ID |
| **核心方法 `generate()`**          | **流程中枢**：包含防御检查、数据计算、连通性清洗、Tile 绘制与信号发射 |
| **辅助逻辑 `_clean_connectivity`** | **拓扑优化**：通过 `_flood_fill_island` 递归检测并剔除无法到达的区域 |
| **辅助逻辑 `_get_atlas_coords`**   | **渲染映射**：将逻辑枚举 `TileType` 转换为图集中实际的像素位置 |





### Systems/map/ZoneManager

#### 1. 核心功能实现

**逻辑区域划分 (Zone Partitioning)**：

- **多类型定义**：通过 `ZoneType` 枚举定义了中立（NEUTRAL）、优势（ADVANTAGE）与劣势（DISADVANTAGE）三种逻辑区域，用于后续资源生成与 AI 策略评估 。
- **基于 Voronoi 图的归类**：采用泰森多边形（Voronoi）算法原理，在地图中随机选取种子点，并将每个可行走格子归类到与其距离最近的种子点所属区域，确保区域的连续性 。

**空间权重分配**：

- **比例控制**：在选取种子点时，通过一个预设的类型池（1中立 + 3优势 + 2劣势）来控制地图上不同类型区域的生成比例和权重 。

**高效数据检索与缓存**：

- **双重存储映射**：同时维护 `tile_zone_map`（坐标到类型）用于调试绘制，以及 `zone_cells_cache`（类型到坐标列表）用于快速提取特定区域的所有坐标（如在优势区生成树木） 。
- **对外数据接口**：通过 `get_coords_in_zone` 函数为其他系统（如实体生成系统）提供按类型检索坐标的能力 。



#### 2. 关键代码内容

| **模块**                      | **实现内容**                                                 |
| ----------------------------- | ------------------------------------------------------------ |
| **枚举定义**                  | `ZoneType`: 包含 `NEUTRAL` (0), `ADVANTAGE` (1), `DISADVANTAGE` (2) 三种区域类型 。 |
| **核心存储**                  | `tile_zone_map` (字典): 记录每个坐标的类型；`zone_cells_cache` (字典): 缓存每类区域对应的坐标数组 。 |
| **主要方法 `generate_zones`** | **区域生成核心**：执行数据重置、种子点随机选取、以及基于欧几里得距离的 Voronoi 分配算法 。 |
| **关键逻辑 `type_pool`**      | **概率控制**：利用 `[0, 1, 1, 1, 2, 2]` 数组在选取种子时自动分配区域占比。 |
| **数据接口**                  | `get_coords_in_zone()`: 封装好的辅助函数，供外部系统快速获取特定区域的所有可用坐标 。 |





## 三、Environment

### Environment/Hurtbox

#### 1. 核心功能实现

**伤害分发与中转（Damage Proxy）**：

- **“传话筒”机制**：该脚本作为一个中转层，主要负责接收来自外部武器（Weapon）或攻击者的伤害请求 。
- **父节点解耦**：通过将具体伤害逻辑转发给其父节点，实现了受击判定区域（Hurtbox）与角色核心逻辑（如生命值管理）的解耦 。

**多方法接口兼容（Interface Compatibility）**：

- **统一入口**：同时支持 `take_damage` 和 `hit` 两种调用方式，确保能与使用不同命名习惯的武器系统无缝对接 。

**安全性验证**：

- **防御性编程**：在转发伤害前，会检查父节点是否存在以及是否实现了必要的处理方法，防止因调用不存在的方法而导致游戏崩溃 。



#### 2. 关键代码内容

| **模块**                     | **实现内容**                                                 |
| ---------------------------- | ------------------------------------------------------------ |
| **基础类型**                 | 继承自 `Area2D`，用于物理碰撞检测 。                         |
| **核心逻辑 `take_damage()`** | **逻辑转发**：获取父节点（`get_parent`）并验证其 `take_damage` 方法的存在性，随后透传伤害量和攻击者信息 。 |
| **兼容方法 `hit()`**         | **别名映射**：直接调用 `take_damage()`，提供对不同攻击调用习惯的兼容支持 。 |





### Environment/ResourceNode

#### 1. 核心功能实现

**资源生命周期管理**：通过 `current_health` 维护资源状态，支持从初始化、受击、血量变化同步（`health_changed`）到枯竭销毁（`depleted`）的全过程逻辑 。

**动态导航障碍生成**：

- **自动构建**：在 `_ready()` 阶段，脚本能根据 `obstacle_radius` 自动计算 12 边形顶点，为资源生成 `NavigationObstacle2D` 障碍物，确保 AI 寻路时会自动绕开树木或矿石 。
- **实时清理**：在资源采集完成销毁前，会优先清理导航障碍节点，确保导航网格能正确响应环境变化 。

**标准采集交互接口**：实现了 `take_damage` 统一接口，允许玩家或 AI 通过调用该方法进行资源采集，并支持传入采集者（`attacker`）信息 。

**物理与视觉反馈**：

- **受击动效**：内置 `_play_hit_effect` 方法，利用 `Tween` 实现 Sprite 的挤压与拉伸，提供即时的交互视觉反馈 。
- **节点清理**：枯竭后调用 `queue_free()` 彻底释放内存并移除物理碰撞体 。

**全局系统集成**：启动时自动将自身加入 `"resources"` 分组，便于 `GameLevelManager` 等上层系统快速检索并统一管理地图上的所有资源点 。



#### 2. 关键代码内容

| **模块**         | **实现内容**                                                 |
| ---------------- | ------------------------------------------------------------ |
| **信号与状态**   | `health_changed` (血量同步), `depleted` (枯竭通知)；`current_health`, `resource_type` (资源类型) |
| **配置参数**     | `auto_setup_obstacle` (导航开关), `obstacle_radius` (碰撞半径), `drop_amount` (单次产出量) |
| **核心交互接口** | `take_damage()`: 负责扣减血量、发射同步信号并触发受击动效，是外部采集的唯一入口 |
| **动态导航逻辑** | `_setup_circle_obstacle()`: 动态计算 12 个顶点的圆周坐标，并赋值给 `NavigationObstacle2D` |
| **清理与销毁**   | `_gather_complete()`: 执行最后的信号发射，并确保在销毁（`queue_free`）前清理导航障碍 |
| **辅助视觉反馈** | `_play_hit_effect()`: 通过 `create_tween()` 对 `Sprite2D` 执行快速的缩放变换动画 |





## 四、Characters

### Characters/Components/SensorSystem

#### 1. 核心功能实现

**程序化激光雷达仿真 (Lidar Simulation)**：

- **全方位覆盖**：通过 `ray_count` 参数动态生成 16 根（可配置）指向不同方向的 `RayCast2D`，实现对角色周围 360 度的无死角环境扫描 。
- **实时探测**：在初始化时自动计算每根射线的角度偏移与目标位置，并将其作为子节点挂载以进行持续的物理碰撞检测 。

**环境特征感知 (Environment Sensing)**：

- **针对性过滤**：利用 `collision_mask` 设定，使传感器专注于探测地形（Layer 1），忽略其他不相关的动态物体，为 AI 避障提供核心数据 。

**标准化数据输出**：

- **距离归一化**：将复杂的物理碰撞坐标转化为 $0.0$ 到 $1.0$ 之间的浮点数（$0.0$ 代表碰撞点极近，$1.0$ 代表未探测到障碍物）。
- **向量化特征**：通过 `get_lidar_data()` 返回一个固定长度的数组，直接作为强化学习（RL）模型的观察空间（Observation Space）输入。



#### 2. 关键代码内容

| **模块**                        | **实现内容**                                                 |
| ------------------------------- | ------------------------------------------------------------ |
| **感知配置**                    | `ray_count` (射线数量), `ray_length` (探测半径), `collision_mask` (碰撞掩码) |
| **内部存储**                    | `_rays`: 存储所有动态创建的 `RayCast2D` 节点引用的数组       |
| **初始化逻辑 `_ready()`**       | **射线矩阵构建**：循环计算 `2 * PI / ray_count` 的步进角度，实例化并激活所有射线 |
| **数据采集 `get_lidar_data()`** | **核心算法**：遍历射线，通过 `is_colliding()` 判断碰撞，并使用 `distance_to` 计算归一化距离 |
| **输出格式**                    | 返回 `Array[float]` 类型数组，是连接物理世界与 AI 算法的桥梁 |





### Characters/BaseUnit

#### 1. 核心功能实现

**高度解耦的控制架构（Pawn-Controller Pattern）**：

- **灵魂附体机制**：作为受控实体（Pawn），通过 `set_controller` 与控制器（Node）绑定 。它不主动决定“去哪”，而是通过鸭子类型（Duck Typing）调用控制器的 `get_move_vector` 和 `get_aim_position` 指令 。
- **自主物理模拟**：在失去控制器时，脚本会自动执行基于摩擦力（Friction）的惯性停车逻辑 。

**生存与资源系统管理**：

- **动态属性追踪**：内置生命值、能量、负重等多维度状态，并通过信号（Signals）实现与 UI 的实时同步 。
- **负重惩罚逻辑**：根据资源持有量（木材/石材）与最大负重的比例，自动计算并更新移动速度修正因子（Speed Modifier），模拟真实负重感 。

**物理运动与导航集成**：

- **平滑移动控制**：结合加速度（Acceleration）和摩擦力，实现丝滑的线性插值（Lerp）移动与旋转转向 。
- **RL 友好型导航**：集成 `NavigationAgent2D` 但默认关闭避障（Avoidance），将避障决策权完全交给强化学习（RL）算法处理 。

**战斗与冷却循环**：

- **统一伤害接口**：提供 `take_damage` 标准方法，支持死亡判定及资源点交互 。
- **自动化技能管理**：在物理帧循环中自动处理多个技能位（技能1、2及终极技能）的冷却倒计时 。



#### 2. 关键代码内容

| **模块**         | **实现内容**                                                 |
| ---------------- | ------------------------------------------------------------ |
| **属性配置**     | `max_health`, `max_weight`, `move_speed`, `acceleration` (物理特性) |
| **控制器接口**   | `set_controller()`: 实现双向绑定逻辑；`controller`: 核心的大脑引用变量 |
| **状态变量**     | `current_health`, `wood_amount`, `cd_skill_1` (冷却时长)     |
| **核心物理循环** | `_physics_process()`: 统一调度冷却倒计时、移动处理、旋转处理与动画 |
| **资源惩罚逻辑** | `add_resource()`: 计算 `weight_ratio` 并动态调用 `update_speed_modifier` |
| **导航组件**     | `@onready var nav_agent`: 初始化检查并配置 `NavigationAgent2D` |





### Characters/Survivor

#### 1. 核心功能实现

**增强型动力与体力系统（Sprint & Stamina）**：

- **动态冲刺**：支持通过消耗能量（`current_energy`）获得爆发性速度（`sprint_speed_multiplier`） 。
- **疲劳保护机制**：引入 `is_exhausted` 状态，当能量耗尽时强制进入疲劳期，直到能量回升至 `exhaustion_threshold` 以上方可再次冲刺 。

**自动化资源采集逻辑（Gathering Action）**：

- **邻近搜索**：利用 `collector_area` (Area2D) 实时探测周围的可交互对象 。
- **间隔控制**：通过 `gather_interval` 计时器限制采集频率，防止瞬间秒杀资源点 。
- **智能交互**：支持直接调用目标物（如树木或矿石）的 `take_damage` 方法，实现采集行为 。

**实时负重与移动惩罚（Encumbrance System）**：

- **动态算速**：重写资源获取逻辑，实时计算 `total_weight` 与 `max_weight` 的比例 。
- **线性减速**：根据负重百分比线性降低移动速度，最低保留 `min_speed_ratio` 的基础机动性 。

**交互视觉反馈**：

- **状态表现**：通过 `Tween` 补间动画实现采集时的旋转抖动和获得资源时的色彩闪烁（Modulate）。

**控制器安全驱动**：

- **输入隔离**：在物理循环中严格检查 `controller` 引用，确保在无控制输入或 AI 未挂载时自动回退到父类的惯性停车状态 。

  

#### 2. 关键代码内容

| **模块**                             | **实现内容**                                                 |
| ------------------------------------ | :----------------------------------------------------------- |
| **属性配置**                         | `sprint_speed_multiplier` (冲刺倍率), `energy_regen` (能量回复), `gather_damage` (采集力) |
| **状态变量**                         | `is_exhausted` (是否疲劳), `_gather_timer` (采集冷却), `_base_speed_cache` (基础速度缓存) |
| **核心引用**                         | `collector_area`: 采集探测范围；`visual_node`: 视觉反馈节点  |
| **核心方法 `_handle_sprint()`**      | **体力管理核心**：处理冲刺状态下的能量扣减与非冲刺状态下的自动回复逻辑 |
| **核心方法 `_perform_chop()`**       | **动作逻辑核心**：触发采集动画并寻找最近的资源点发送伤害指令 |
| **辅助逻辑 `_update_encumbrance()`** | **负重算法**：基于 `1.0 - weight_percent` 计算速度修正系数并应用至底层物理 |





## 五、Control

### Control/BaseController

#### 1. 核心功能实现

**“灵魂附体”架构 (Possession System)**：

- **躯壳绑定机制**：通过 `possess()` 方法将控制器（大脑）与 `CharacterBody2D` 单位（肉体）绑定，并确立双向引用关系（控制器持有 `pawn`，单位持有 `controller` 。
- **热切换支持**：在附身新单位前，会自动断开与旧单位的信号连接并重置其引用，支持控制器在不同躯壳间无缝切换 。

**信号驱动的 UI 同步**：

- **自动化通信**：自动监听被控单位的生命值（`health_changed`）、能量（`energy_changed`）及资源（`resource_changed`）信号 。
- **实时数据分发**：当单位状态变化时，控制器通过回调函数将最新数据转发给 `MainHUD` 界面进行展示 。

**规范化输入接口 (Virtual Interfaces)**：

- **指令抽象**：定义了一套标准的虚拟方法（如 `get_move_vector`、`wants_to_sprint`），为上层子类（玩家控制或 AI 控制）提供了统一的行动指令模板 。

**生命周期安全管理**：

- **自动清理**：在控制器节点从树中移除（`_exit_tree`）时，自动执行断开连接逻辑，防止空指针崩溃或信号残留 。



#### 2. 关键代码内容

| **模块**                 | **实现内容**                                                 |
| ------------------------ | ------------------------------------------------------------ |
| **状态变量**             | `pawn` (被控单位引用), `main_hud` (UI 引用), `debug` (调试开关) |
| **核心方法 `possess()`** | **逻辑中枢**：负责断开旧连接、绑定新肉体、重命名调试节点及初始化 UI 同步 |
| **信号管理**             | `_connect_pawn_signals()` / `_disconnect_pawn_signals()`: 封装了信号的鲁棒性连接与断开逻辑 |
| **UI 回调**              | `_on_pawn_health_changed()` 等：将单位发出的物理信号转化为 UI 更新指令 |
| **虚拟接口集**           | `get_move_vector()`, `wants_to_interact()`, `get_aim_position()`: 待子类实现的输入逻辑 |





### Control/PlayerController

#### 1. 核心功能实现

**游戏状态感知的输入拦截**：

- **全局状态同步**：通过引用 `GameLevelManager` 实时监测当前游戏状态 。
- **条件准入机制**：实现 `_can_input()` 逻辑，确保只有当游戏处于 `PLAYING`（进行中）状态且已附身单位时，才允许玩家输入有效指令 。

**物理操作指令映射**：

- **全向移动控制**：利用 `Input.get_vector` 将键盘（WASD）或手柄输入转化为归一化的移动向量 。
- **交互与行动意图**：封装了攻击（Attack）、采集（Interact）及冲刺（Sprint）的布尔值查询接口，支持连续按住操作 。

**动态朝向逻辑（Look-Ahead Aiming）**：

- **移动导向瞄准**：舍弃鼠标跟随，改为根据移动向量自动计算瞄准位置。角色会看向当前移动方向前方 100 像素的点，实现更符合动作游戏的自动化转向表现 。

**调试与输入监控**：

- **静默调试输出**：在 `debug` 模式开启下，通过 `_debug_input_check` 实时打印移动和攻击指令 。
- **输入去重优化**：通过 `_last_move_vector` 记录上一帧状态，仅在输入发生变化时打印日志，避免控制台刷屏 。



#### 2. 关键代码内容

| **模块**                          | **实现内容**                                                 |
| --------------------------------- | ------------------------------------------------------------ |
| **外部引用**                      | `_level_manager`: 核心状态源；`_last_move_vector`: 用于日志去重 |
| **拦截逻辑 `_can_input()`**       | **核心管控**：检查 `pawn` 是否有效及 `current_state` 是否为 `PLAYING` |
| **接口实现 `get_move_vector()`**  | **移动映射**：绑定 `move_left/right/up/down` 动作，状态不符时返回 `Vector2.ZERO` |
| **接口实现 `get_aim_position()`** | **转向算法**：逻辑为 `pawn.global_position + (move_dir * 100.0)`，实现“看向前方” |
| **交互接口集**                    | `wants_to_interact()`: 采集判定；`wants_to_sprint()`: 冲刺意图判定 |





### Control/RLAgentController

#### 1. 核心功能实现

**强化学习接口集成 (Godot RL Agents Integration)**：

- **观察空间映射 (Observation Space)**：定义了高度细化的 20 个特征维度，包括单位属性（血量、能量、坐标）、资源保有量、技能冷却状态以及环境感知数据 。
- **动作空间映射 (Action Space)**：支持 9 类动作输入，其中移动为 2 维连续动作，攻击、冲刺、采集及建造等为 1 维连续动作（通过阈值判定触发） 。

**多源环境感知系统**：

- **雷达特征提取**：动态调用 `SensorSystem` 获取 16 根射线的归一化距离数据，作为 AI 避障的核心输入 。
- **导航引导 (Navigation Hint)**：通过 `nav_agent` 计算当前位置到下一个路径点的方向向量，并提供可调强度的导航指引（`nav_hint_strength`），辅助 AI 学习路径规划 。

**奖励逻辑与目标导向**：

- **生存与惩罚**：每帧提供基础生存奖励，并在单位阵亡时施加大幅度的负面惩罚（-10.0） 。
- **资源获取激励**：将实时的资源收益（木材、石材）转化为奖励权重，诱导 AI 学习高效的采集行为 。

**鲁棒的动作执行器**：

- **安全解析机制**：通过 `set_action()` 接收来自外部训练框架的张量数据，并使用 `has()` 检查各动作键值，防止因缺失数据导致的逻辑中断或模型报错 。
- **状态接口对齐**：通过重写 `get_move_vector()` 等虚函数，将 AI 的决策指令无缝转换为 `BaseUnit` 的物理行为 。



#### 2. 关键代码内容

| **模块**                    | **实现内容**                                                 |
| --------------------------- | ------------------------------------------------------------ |
| **状态变量**                | `_current_move` (移动缓存), `_wants_sprint` (冲刺意图), `nav_hint_strength` (引导强度) |
| **核心引用**                | `pawn` (受控实体), `sensor_system` (雷达), `game_manager` (管理器) |
| **奖励函数 `get_reward()`** | **逻辑核心**：组合了 `current_health` 死亡惩罚与 `resource_gain` 采集激励 |
| **特征提取 `get_obs()`**    | **数据归一化**：将坐标、血量比率及 16 维雷达数据封装为符合 ML 模型要求的字典 |
| **动作映射 `set_action()`** | **映射机制**：通过 `> 0.5` 的布尔判定将连续动作值转化为具体的指令开关 |
| **辅助逻辑 `possess()`**    | **动态组件挂载**：附身单位时自动检查并添加 `SensorSystem` 雷达节点 |





## 六、UI

### UI/MainHUD

#### 1. 核心功能实现

**动态角色模式重塑 (Role-Based HUD Reconstruction)**：

- **职业感知布局**：根据 `RoleType`（工兵或战士）自动调整 UI 元素的可见性与表现形式 。
- **定制化反馈**：针对工兵（BUILDER）显示资源面板并使用黄色体力条；针对战士（WARRIOR）则隐藏资源面板，并将体力条转换为橙红色以模拟“怒气值”表现 。

**多维状态实时监控 (Real-time Status Monitoring)**：

- **基础属性同步**：提供血量（Health）和能量（Energy）的更新接口，通过 `ProgressBar` 直观展示当前值与最大值的比例 。
- **资源与负重警告**：实时显示木材、石材数量，并监控当前负重。当负重超过最大限制时，负重标签会自动变红以警示玩家 。

**技能冷却可视化 (Skill Cooldown Visualization)**：

- **遮罩动态反馈**：利用 `TextureProgressBar` 实现技能冷却（CD）遮罩。根据剩余时间百分比动态调整遮罩进度，并在冷却结束时自动隐藏 。

**健壮性与调试支持**：

- **路径防御检查**：在更新数据时对 UI 节点引用进行有效性校验，若节点缺失则通过控制台打印具体的错误定位信息，便于开发调试 。



#### 2. 关键代码内容

| **模块**                           | **实现内容**                                                 |
| ---------------------------------- | ------------------------------------------------------------ |
| **职业定义**                       | `enum RoleType`: 包含 `BUILDER` (工兵) 与 `WARRIOR` (战士) 两种模式 |
| **状态变量**                       | `health_bar`, `energy_bar` (状态条); `resource_panel` (资源面板); `cd_mask` (冷却遮罩) |
| **核心方法 `setup_hud()`**         | **模式中枢**：根据角色类型调用私有的 `_setup_mode` 函数切换图标、颜色及面板可见性 |
| **接口 `update_energy()`**         | **数据同步**：包含最大值校验逻辑及针对节点路径错误的防御性打印 |
| **接口 `update_resources()`**      | **逻辑判定**：根据 `current_weight > max_weight` 动态修改 `modulate` 颜色属性 |
| **接口 `update_skill_cooldown()`** | **视觉计算**：将 `time_left / total_cooldown` 转化为百分比并驱动 CD 遮罩 |





# 三、模块之间的关系

## 1. 宏观架构视图 (High-Level Architecture)

整个项目呈金字塔结构，由上至下进行管理和分发：

- **👑 核心管理层 (Core Manager)**
  - **`GameLevelManager`**: 绝对的指挥官。它持有所有子系统的引用，负责协调游戏的加载、开始、结束、数据统计和重置循环。
- **⚙️ 系统层 (Systems)**
  - **`ControlSystem` (战略指挥部)**: 负责宏观调度所有 AI。它不处理具体的物理移动，只负责为 AI 分配“目标”（例如：告诉 AI 最近的资源在哪里）。
  - **`MapGenerator` (施工队)**: 统筹地形生成、区域划分和导航网格烘焙。
  - **`ObjectSpawner` (兵工厂)**: 工具模块。只负责根据指令在地图上“生产”和“销毁”实体，不包含游戏逻辑。
- **🧠 控制层 (Controllers)**
  - **`BaseController`及其子类**: 它是“大脑”。作为独立节点存在（对象池模式），在游戏重置时不被销毁，只是更换控制的躯壳。
- **♟️ 实体层 (Entities)**
  - **`Survivor` (躯壳)**: 负责执行物理移动、动画和交互。它没有自主意识，完全听命于 Controller。
  - **`ResourceNode` (环境)**: 可交互的资源点，负责阻挡导航和反馈采集结果。

------

## 2. 详细调用流程与生命周期 (Lifecycle & Call Flow)

### A. 启动与初始化 (Startup)

1. **启动**: `GameLevelManager._ready()` 被调用，状态设为 `LOADING`。
2. **大脑初始化**: 调用 `_init_controllers()`。
   - 实例化 1 个 `PlayerController` 和 11 个 `RLAgentController`。
   - 将它们挂载到 `ControlSystem` 下（作为对象池待命）。
3. **请求地图**: 调用 `map_system.start_generation()` 。

### B. 地图生成与实体布置 (Generation)

1. **地形流水线**: `MapGenerator` 依次驱动 `TerrainGenerator` (生成地貌) -> `ZoneManager` (划分区域)。
2. **就绪回调**: 地图完成后发出 `map_ready` 信号，触发 `GameLevelManager._on_map_ready` 。
3. **生产实体**: 管理器调用 `spawner.spawn_entities()`。
   - `ObjectSpawner` 清理上一局残留的物体 (`_clear_all_entities`) 。
   - 在可行走区域随机生成 `Survivor` (幸存者)、树木和矿石，并返回生成的单位数组 。
4. **导航烘焙**: 管理器等待物理帧更新 (`await physics_frame`)，然后调用 `NavigationRegion2D.bake_navigation_polygon()`，确保新生成的资源阻挡被纳入导航网格 。

### C. 灵魂附体 (Possession)

这是连接“控制层”与“实体层”的关键步骤，在 `_assign_units` 中执行：

1. **模式判断**:
   - **普通模式**: 第 1 个单位分给玩家，其余给 AI。
   - **训练模式**: 跳过玩家，所有单位分配给 AI 。
2. **绑定执行**: 调用 `controller.possess(unit)` 。
   - **引用建立**: `unit.controller = controller`。
   - **信号订阅**: 控制器订阅单位的 `health_changed`、`resource_changed` 等信号，用于 UI 同步或 RL 奖励计算。

### D. 游戏主循环 (Gameplay Loop)

状态转变为 `PLAYING`，`ControlSystem` 被激活，进入帧循环：

- **层级 1：宏观调度 (ControlSystem)** 
  - 每隔一定帧数（如10帧）运行一次。
  - 遍历所有 AI 控制器，计算离它们最近的资源点。
  - **指令下达**: 更新 `controller.pawn.nav_agent.target_position`。注意：这只是设置导航路标，不直接移动单位。
- **层级 2：微观决策 (RLAgentController)** 
  - **感知**: 通过 `SensorSystem` 获取雷达数据，通过 `nav_agent` 获取导航引导向量 (`nav_hint`)。
  - **决策**: 将感知数据输入神经网络（在 Python 端或推理模型中），输出动作向量 (`move`, `attack`, `interact`)。
  - **指令转化**: 将动作向量缓存为具体的意图标志位（如 `_wants_sprint`, `_current_move`）。
- **层级 3：物理执行 (Survivor)** 
  - **物理帧**: `_physics_process` 运行。
  - **询问**: 调用 `controller.get_move_vector()` 获取移动方向。
  - **执行**: 调用 `move_and_slide()` 进行物理运动，或调用 `take_damage()` 进行采集交互。

### E. 交互与反馈 (Interaction)

1. **采集**: `Survivor` 检测到采集意图 -> 寻找最近的 `ResourceNode` -> 调用 `take_damage`。
2. **反馈**: 资源血量归零 -> 发出 `depleted` 信号 -> 销毁自身 -> 移除导航阻挡 。
3. **同步**: 幸存者获得资源 -> 触发 `resource_changed` -> 控制器收到信号 -> `MainHUD` 更新 UI 。

### F. 结束与重置 (Reset) 

1. **监控**: `GameLevelManager` 监控时间耗尽或全员阵亡 。
2. **保存**: 将本局存活时间与资源量写入 `training_logs.csv` 。
3. **重置**:
   - **断开连接**: `controller.pawn = null` (大脑与尸体分离)。
   - **重启生成**: 再次调用 `map_system.start_generation()`，进入下一轮训练闭环。
